# encoding: UTF-8

import vtConstant
from shzd2Gateway import Shzd2Gateway as gateway

gatewayName = 'SHZD2'
gatewayDisplayName = u'直达2'
gatewayType = vtConstant.GATEWAYTYPE_INTERNATIONAL
gatewayQryEnabled = True